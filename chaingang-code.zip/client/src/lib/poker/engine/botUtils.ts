// ─── Re-export shim ───────────────────────────────────────────────────────────
// Bot utilities now live in shared/engine/botUtils so the server engine
// can also import them. All existing client imports continue to work.
export * from '@shared/engine/botUtils';
